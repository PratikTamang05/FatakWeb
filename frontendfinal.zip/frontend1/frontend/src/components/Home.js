import React from "react";
import image from "../images/new.jpg";
import { Link } from "react-router-dom";
export default function Home() {
  return (
    <>
      <div
        id="carouselExampleCaptions"
        className="carousel slide"
        data-bs-ride="false"
        // style={{ marginTop: "40px" }}
      >
        <div className="carousel-inner">
          <div className="carousel-item active">
            <img src={image} className="d-block w-100" alt="..." />
            <div className="carousel-caption d-none d-md-block">
              <h5>Unity is Strength</h5>
              <p>Serving you since 1996 </p>
            </div>
          </div>
        </div>
      </div>
      <div className="bg-dark text-light" style={{ height: "200px" }}>
        <h5 className="text-start my-3   mx-3">
          Hey it's always good to hear from you. Wanna share some stories with
          the community?
        </h5>

        <div>
          <span style={{ float: "left" }}>
            <Link to="/sharearticles">
              <button type="button" className="btn btn-warning my-3 mx-3">
                Share
              </button>
            </Link>

            <Link to="/articles">
              <button type="button" className="btn btn-warning ">
                Read Stories by our members
              </button>
            </Link>
          </span>
        </div>
      </div>
    </>
  );
}
