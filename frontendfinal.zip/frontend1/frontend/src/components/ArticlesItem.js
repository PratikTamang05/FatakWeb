import React from "react";
import { Link } from "react-router-dom";
export default function ArticlesItem(props) {
  const { id, title, content, author } = props;
  // console.log(props);
  // console.log({ author });
  return (
    <div className="my-3">
      <div className="card" style={{ backgroundColor: "#33333b" }}>
        <div
          style={{
            display: "flex",
            justifyContent: "flex-end",
            position: "absolute",
            right: "0",
          }}
        >
          {/* <span className="badge rounded-pill bg-danger"> Test Source</span> */}
        </div>
        {/* <img
          src="https://fdn.gsmarena.com/imgroot/news/21/08/xiaomi-smart-home-india-annoucnements/-476x249w4/gsmarena_00.jpg"
          className="card-img-top"
          alt="..."
        /> */}
        <div className="card-body">
          <h5 className="card-title text-light">{title} </h5>
          <p className="card-text text-light">{content}</p>
          <p className="card-text">
            <small className="text-muted">By {author} </small>
          </p>
          <Link className="btn btn-sm btn-dark" to={`/articles/${id}`}>
            Read More
          </Link>
        </div>
      </div>
    </div>
  );
}
