import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
export default function HofDetails() {
  const [hof, setHof] = useState([]);

  useEffect(() => {
    const fetchHof = async () => {
      try {
        const res = await axios.get("http://localhost:8800/hofdetails");
        //console.log(res);
        setHof(res.data);
      } catch (err) {
        console.log(err);
      }
    };
    fetchHof();
  }, []);
  //console.log(hof);
  return (
    <>
      <div className="container">
        <h3 className="text-light my-3 text-start">
          List of all Head of Families
        </h3>
        <ul className="list-group my-3">
          {hof.map((element) => {
            return (
              <Link
                to="/articles"
                className="text-white"
                key={element.aadharNo}
              >
                <li
                  className="list-group-item bg-dark text-light text-start"
                  style={{ borderColor: "#555050" }}
                >
                  {element.name}
                </li>
              </Link>
            );
          })}
        </ul>
      </div>
    </>
  );
}
