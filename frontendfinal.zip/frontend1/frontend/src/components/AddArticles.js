import React, { useState } from "react";
import axios from "axios";
import { addArticle } from "../store/slices/addArticleSlice";
import { useDispatch } from "react-redux";
export default function AddArticles() {
  const dispatch = new useDispatch();
  const [article, setArticle] = useState({
    title: "",
    author: "",
    content: "",
  });
  const handleInputChange = (fieldName, value) => {
    setArticle((prevData) => ({
      ...prevData,
      [fieldName]: value,
    }));
  };
  // console.log(article);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // console.log("clicked");
      // console.log(formData);
      await axios.post("http://localhost:8800/shareArticles", article);
      dispatch(addArticle(article));

      // navigate("/");
    } catch (err) {
      console.log(err);
    }
  };
  return (
    <>
      <div className="container text-light">
        <h3 className="text-light my-5 text-start">Submit Article</h3>
        <div className="mb-3">
          <div className="text-start">Author</div>
          <div className="row ">
            <div className="col-md-6">
              <input
                type="text"
                className="form-control"
                id="author"
                onChange={(e) => handleInputChange("author", e.target.value)}
              />
            </div>
          </div>
        </div>
        <div className="mb-3">
          <div className="text-start">Article Title</div>
          <div className="row ">
            <div className="col-md-6">
              <input
                type="text"
                className="form-control"
                id="title"
                onChange={(e) => handleInputChange("title", e.target.value)}
              />
            </div>
          </div>
        </div>
        <div className="mb-3">
          <div className="form-label text-start">Article Body</div>
          <div className="row">
            <div className="col-md-8">
              <textarea
                className="form-control"
                id="exampleFormControlTextarea1"
                rows="6"
                onChange={(e) => handleInputChange("content", e.target.value)}
              ></textarea>
            </div>
          </div>
        </div>
        <div className="mb-3">
          <div className="row ">
            <div className="col-md-6">
              <button
                type="button"
                className="btn btn-primary col-md-2 my-3"
                style={{ float: "left" }}
                onClick={handleSubmit}
              >
                Submit
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
