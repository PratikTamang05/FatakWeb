import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";

import axios from "axios";
export default function MemberDetails(props) {
  const [numberOfForms, setNumberOfForms] = useState(null);
  const hof = useSelector((state) => state.familyDetails.hofDetails);

  const [formsArray, setFormsArray] = useState([]);
  const [membersInfo, setMembersInfo] = useState([]);

  function createObject() {
    return {
      name: "",
      dob: "",
      sex: "",
      phoneNo: "",
      bloodGroup: "",
      Education: "",
      occupation: "",
      Category: "",
      hofAadharNo: hof.aadharNo,
    };
  }
  //console.log(props.members);
  useEffect(() => {
    //console.log("1st");
    // console.log location)
    const integerFromStore = props.members;
    setNumberOfForms(integerFromStore);
  }, [props.members]);

  useEffect(() => {
    //  console.log("heyyyyyyyyy");
    //console.log(membersInfo);
    async function sendData() {
      try {
        await axios.post("http://localhost:8800/addmemberDetails", membersInfo);
        //setFinalSubmit(true);
        // navigate("/");
      } catch (err) {
        console.log(err);
      }
    }
    sendData();
    // console.log("memberdetails " + props.submit);
  }, [props.submit]);

  useEffect(() => {
    // console.log("2nd");
    const newArray = Array.from({ length: numberOfForms }, (_, index) => index);

    const arrayOfObjects = Array.from({ length: numberOfForms }, (_, index) =>
      createObject(index)
    );

    setFormsArray(newArray);
    setMembersInfo(arrayOfObjects);
  }, [numberOfForms]);
  //console.log(membersInfo);

  const handleInputChange = (index, fieldName, value) => {
    setMembersInfo((prevDataArray) => {
      return prevDataArray.map((item, i) => {
        if (i === index) {
          return { ...item, [fieldName]: value };
        }
        return item;
      });
    });
  };
  //console.log(membersInfo);
  return (
    <>
      <div className="container">
        <h2 className="my-4 text-light">Member Details</h2>
        <div>
          {formsArray.map((i) => {
            return (
              <div className="col-md-12" key={i}>
                <h4 className="text-start text-light">Member {i + 1}</h4>
                <form
                  className="card p-3 my-4"
                  style={{ backgroundColor: "#33333b" }}
                >
                  <div className="col-md-6">
                    <div
                      htmlFor="inputName"
                      className="text-start my-1 text-light"
                    >
                      Name
                    </div>
                    <input
                      type="email"
                      className="form-control"
                      id="inputName"
                      onChange={(e) =>
                        handleInputChange(i, "name", e.target.value)
                      }
                    />
                  </div>
                  <div className="col-md-6">
                    <div
                      htmlFor="inputDOB"
                      className="text-start my-1 text-light"
                    >
                      Date of Birth
                    </div>
                    <input
                      type="text"
                      className="form-control"
                      id="inputDOB"
                      onChange={(e) =>
                        handleInputChange(i, "dob", e.target.value)
                      }
                    />
                  </div>
                  <div className="col-6">
                    <div
                      htmlFor="inputSex"
                      className="text-start my-1 text-light"
                    >
                      Sex
                    </div>
                    <input
                      type="text"
                      className="form-control"
                      id="inputSex"
                      placeholder="1234 Main St"
                      onChange={(e) =>
                        handleInputChange(i, "sex", e.target.value)
                      }
                    />
                  </div>

                  <div className="col-md-6">
                    <div
                      htmlFor="inputPhoneNo"
                      className="text-start my-1 text-light"
                    >
                      Phone No
                    </div>
                    <input
                      type="text"
                      className="form-control"
                      id="inputPhoneNo"
                      onChange={(e) =>
                        handleInputChange(i, "phoneNo", e.target.value)
                      }
                    />
                  </div>
                  <div className="col-md-6">
                    <div
                      htmlFor="inputBloodGroup"
                      className="text-start my-1 text-light"
                    >
                      Blood Group
                    </div>
                    <input
                      type="text"
                      className="form-control"
                      id="inputBloodGroup"
                      onChange={(e) =>
                        handleInputChange(i, "bloodGroup", e.target.value)
                      }
                    />
                  </div>
                  <div className="col-md-6">
                    <div
                      htmlFor="inputEQ"
                      className="text-start my-1 text-light"
                    >
                      Educational Qualification
                    </div>
                    <input
                      type="text"
                      className="form-control"
                      id="inputEQ"
                      onChange={(e) =>
                        handleInputChange(i, "Education", e.target.value)
                      }
                    />
                  </div>
                  <div className="col-md-6">
                    <div
                      htmlFor="inputOccupation"
                      className="text-start my-1 text-light"
                    >
                      occupation
                    </div>
                    <input
                      type="text"
                      className="form-control"
                      id="inputOccupation"
                      onChange={(e) =>
                        handleInputChange(i, "occupation", e.target.value)
                      }
                    />
                  </div>
                  <div className="col-md-6">
                    <div
                      htmlFor="inputCategory"
                      className="text-start my-1 text-light"
                    >
                      Category
                    </div>
                    <input
                      type="text"
                      className="form-control"
                      id="inputCategory"
                      onChange={(e) =>
                        handleInputChange(i, "Category", e.target.value)
                      }
                    />
                  </div>
                </form>
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
}
