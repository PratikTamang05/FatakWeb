import axios from "axios";
import React, { useEffect, useState } from "react";
import ArticlesItem from "./ArticlesItem";
export default function Articles() {
  /*  const setState = () => {
    console.log("Articles");
  }; */
  const [articles, setArtciles] = useState([]);

  useEffect(() => {
    const fetchAllArticles = async () => {
      try {
        const res = await axios.get("http://localhost:8800/articles");
        //console.log(res);
        setArtciles(res.data);
      } catch (err) {
        console.log(err);
      }
    };
    fetchAllArticles();
  }, []);

  //setArtciles(counter);
  //console.log(counter);
  //console.log(articles);
  return (
    <div
      className="bg-dark text-light"
      style={{ width: "100vw", height: "100vh" }}
    >
      <h4>Articles by our members</h4>

      <div className="container">
        <div className="row bg-dark">
          {articles.map((element) => {
            return (
              <div className="col-md-4 my-3" key={element.id}>
                <ArticlesItem
                  id={element.id}
                  title={element.title}
                  content={element.content}
                  author={element.Author}
                />
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
