import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { addHof } from "../store/slices/headOfFamily";
import MemberDetails from "./MemberDetails";
import axios from "axios";
//import { Link } from "react-router-dom";
export default function AddMember() {
  const dispatch = useDispatch();
  const [isFormVisible, setIsFormVisible] = useState(true);
  const hof = useSelector((state) => state.familyDetails.hofDetails);
  const [finalSubmit, setFinalSubmit] = useState(false);
  // State to manage form input values
  const [formData, setFormData] = useState({
    headoffamily: hof.headoffamily,
    aadharNo: hof.aadharNo,
    religion: hof.religion,
    fullAddress: hof.fullAddress,
    holdingNo: hof.holdingNo,
    wardNo: hof.wardNo,
    primaryDiet: hof.primaryDiet,
    totalMembers: 0,
  });
  const handleInputChange = (fieldName, value) => {
    // Update the local form data
    setFormData((prevData) => ({
      ...prevData,
      [fieldName]: value,
    }));
  };
  const handleFromShow = () => {
    if (isFormVisible) setIsFormVisible(false);
    else setIsFormVisible(true);
  };
  const handleFormSubmit = () => {
    // Dispatch the updateUserInfo action with the entire updated object
    dispatch(addHof(formData));
    setIsFormVisible(false);
  };
  //console.log(hof.totalMembers);

  const handleFinalSubmit = (e) => {
    submitAllData(e);
  };

  const submitAllData = async (e) => {
    e.preventDefault();
    try {
      // console.log("clicked");
      // console.log(formData);
      await axios.post("http://localhost:8800/addHOF", formData);
      setFinalSubmit(true);
      // navigate("/");
    } catch (err) {
      console.log(err);
    }
  };
  return (
    <div className="bg-dark">
      <h3 className=" text-light ">Head of Family Details</h3>
      <div className="container col-xs-12 col-md-8 col-md-offset-2">
        {isFormVisible && (
          <form
            className="card p-3 my-1"
            style={{ backgroundColor: "#33333b" }}
          >
            <div className="col-md-6">
              <div htmlFor="inputEmail4" className="text-start my-1 text-light">
                Head of Family
              </div>
              <input
                type="email"
                className="form-control"
                id="inputEmail4"
                onChange={(e) =>
                  handleInputChange("headoffamily", e.target.value)
                }
              />
            </div>
            <div className="col-md-6">
              <div htmlFor="inputEmail4" className="text-start my-1 text-light">
                Aadhar Number
              </div>
              <input
                type="text"
                className="form-control"
                id="inputEmail4"
                onChange={(e) => handleInputChange("aadharNo", e.target.value)}
              />
            </div>
            <div className="col-md-6">
              <div
                htmlFor="inputPassword4"
                className="text-start my-1 text-light"
              >
                Religion
              </div>
              <input
                type="text"
                className="form-control"
                id="inputPassword4"
                onChange={(e) => handleInputChange("religion", e.target.value)}
              />
            </div>
            <div className="col-md-6">
              <div
                htmlFor="inputAddress"
                className="text-start my-1 text-light"
              >
                Full Address
              </div>
              <input
                type="text"
                className="form-control"
                id="inputAddress"
                onChange={(e) =>
                  handleInputChange("fullAddress", e.target.value)
                }
              />
            </div>
            <div className="col-md-6">
              <div htmlFor="inputCity" className="text-start my-1 text-light">
                Holding No
              </div>
              <input
                type="text"
                className="form-control"
                id="inputCity"
                onChange={(e) => handleInputChange("holdingNo", e.target.value)}
              />
            </div>
            <div className="col-md-4">
              <div htmlFor="inputWard" className="text-start my-1 text-light">
                Ward No
              </div>
              <input
                type="text"
                className="form-control"
                id="inputZip2"
                onChange={(e) => handleInputChange("wardNo", e.target.value)}
              />
            </div>
            <div className="col-md-4">
              <div htmlFor="inputDiet" className="text-start my-1 text-light">
                Primary Diet
              </div>
              <input
                type="text"
                className="form-control"
                id="inputZip"
                placeholder="Eg: Veg/Non-Veg"
                onChange={(e) =>
                  handleInputChange("primaryDiet", e.target.value)
                }
              />
            </div>
            <div className="col-md-4">
              <div
                htmlFor="inputMembers2"
                className="text-start my-1 text-light"
              >
                Total Members Excluding HOF
              </div>
              <input
                type="text"
                className="form-control"
                id="inputMembers"
                onChange={(e) =>
                  handleInputChange("totalMembers", e.target.value)
                }
              />
            </div>
            <button
              type="button"
              className="btn btn-primary col-md-1 my-3"
              onClick={handleFormSubmit}
            >
              Submit
            </button>
          </form>
        )}

        <button
          type="button"
          className="btn bg-secondary "
          onClick={handleFromShow}
          hidden={isFormVisible}
        >
          Refill HOF Details
        </button>

        {hof.totalMembers > 0 && !isFormVisible && (
          <MemberDetails members={hof.totalMembers} submit={finalSubmit} />
        )}

        {hof.totalMembers > 0 && !isFormVisible && (
          <button
            className="btn bg-secondary col-md-2 my-3"
            onClick={handleFinalSubmit}
          >
            Final Submit
          </button>
        )}
      </div>
    </div>
  );
}
