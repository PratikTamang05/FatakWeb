import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
export default function IndividualArticle() {
  // const id = match.params.id;
  const { id } = useParams();
  const [loading, setLoading] = useState(true);
  const [article, setArticle] = useState({
    title: "",
    author: "",
    content: "",
  });
  useEffect(() => {
    const fetchArticle = async () => {
      try {
        //const res = await axios.get("http://localhost:8800/articles");
        const res = await axios.get(
          `http://localhost:8800/individualArtcile/${id}`
        );
        //console.log(res);
        setArticle(res.data);
        setLoading(false);
      } catch (err) {
        console.log(err);
      }
    };

    fetchArticle();
  }, []);

  console.log(article);
  return (
    <>
      <div className="container">
        {loading ? (
          <p className="text-light">Loading....</p>
        ) : (
          <div className="row">
            <h2 className="text-light text-start my-3">{article[0].title}</h2>
            <div className="col-md-8 my-3 text-light text-start">
              {article[0].content}
            </div>
            <div className="col-md-3 my-3">
              <ul className="list-group ">
                <li
                  className="list-group-item bg-dark text-light"
                  style={{ borderColor: "#555050" }}
                >
                  Author: {!article[0].Author ? "Anonymous" : article[0].Author}
                </li>
                <li
                  className="list-group-item bg-dark text-light"
                  style={{ borderColor: "#555050" }}
                >
                  Published on : 28 Jan
                </li>
                <li
                  className="list-group-item bg-dark text-light "
                  style={{ borderColor: "#555050" }}
                >
                  Word count: {article[0].content.trim().split(" ").length}
                </li>
              </ul>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
