import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import AddMember from "./components/AddMember";
import Home from "./components/Home";
import Navbar from "./components/Navbar";
import MemberDetails from "./components/MemberDetails";
import Articles from "./components/Articles";
import Footer from "./components/Footer";
import AddArticles from "./components/AddArticles";
import IndividualArticle from "./components/IndividualArticle";
import HofDetails from "./components/HofDetails";
function App() {
  return (
    <div className="App bg-dark">
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/addmember" element={<AddMember />} />
          <Route path="/memberdetails" element={<MemberDetails />} />
          <Route path="/articles" element={<Articles />} />
          <Route path="/sharearticles" element={<AddArticles />} />
          <Route path="/articles/:id" element={<IndividualArticle />} />
          <Route path="/hofdetails" element={<HofDetails />} />
        </Routes>
        <Footer />
      </BrowserRouter>
    </div>
  );
}

export default App;
