import { configureStore } from "@reduxjs/toolkit";
import familyDetailsSlice from "./slices/headOfFamily";
import articleDetailsSlice from "./slices/addArticleSlice";
const store = configureStore({
  reducer: {
    familyDetails: familyDetailsSlice,
    articleDetails: articleDetailsSlice,
  },
});

export default store;
