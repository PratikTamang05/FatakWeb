import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  articleDetails: {
    title: "",
    author: "",
    content: "",
  },
};
var articleDetailsSlice = createSlice({
  name: "articleDetails",
  initialState,
  reducers: {
    addArticle(state, action) {
      state.articleDetails = action.payload;
      console.log(action.payload);
    },
  },
});

//console.log(familyDetailsSlice.actions);
export default articleDetailsSlice.reducer;
export const { addArticle } = articleDetailsSlice.actions;
