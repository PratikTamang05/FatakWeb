import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  hofDetails: {
    headoffamily: "",
    aadharNo: "",
    religion: "",
    fullAddress: "",
    holdingNo: "",
    wardNo: "",
    primaryDiet: "",
    totalMembers: 0,
  },
};
var familyDetailsSlice = createSlice({
  name: "familyDetails",
  initialState,
  reducers: {
    addHof(state, action) {
      state.hofDetails = action.payload;
      //console.log(action.payload);
    },
  },
});

//console.log(familyDetailsSlice.actions);
export default familyDetailsSlice.reducer;
export const { addHof } = familyDetailsSlice.actions;
