import express from "express";
import mysql from "mysql";
import cors from "cors";

const app = express();

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "Pratik123#",
  database: "test",
});
//var foreginKey = "";
app.use(cors());
app.use(express.json());

app.get("/articles", (req, res) => {
  const q = "Select * from fatakdb.articles";
  db.query(q, (err, data) => {
    if (err) return res.json(err.message);
    return res.json(data);
  });
});

app.get("/hofdetails", (req, res) => {
  const q = "Select * from fatakdb.hofdetails";
  db.query(q, (err, data) => {
    if (err) return res.json(err.message);
    return res.json(data);
  });
});

app.get("/individualArtcile/:id", (req, res) => {
  const id = req.params.id;
  const q = `Select * from fatakdb.articles where id = ${id}`;
  //console.log(q);
  db.query(q, (err, data) => {
    if (err) return res.json(err.message);
    return res.json(data);
  });
});

app.post("/addHOF", (req, res) => {
  const q =
    "Insert into fatakdb.hofdetails(`name`,`aadharNo`,`religion`,`address`,`holdingNo`,`wardNo`,`primaryDiet`,`totalMembers`) VALUES (?)";
  // foreginKey = req.body.aadharNo;
  const values = [
    req.body.headoffamily,
    req.body.aadharNo,
    req.body.religion,
    req.body.fullAddress,
    req.body.holdingNo,
    req.body.wardNo,
    req.body.primaryDiet,
    req.body.totalMembers,
  ];
  db.query(q, [values], (err, data) => {
    if (err) return res.json(err.message);
    return res.json("Book has been created successfully");
  });
});

app.post("/addmemberDetails", (req, res) => {
  const q =
    "Insert into fatakdb.memberDetails(`hofAadharNo`,`name`,`dob`,`sex`,`phoneNo`,`bloodGroup`,`education`,`occupation`,`category`) VALUES (?)";
  // console.log(req.body);
  var arr = [];
  const dataFromBody = req.body;
  if (Array.isArray(dataFromBody)) arr.push(...dataFromBody);
  if (arr.length > 0) {
    for (var i = 0; i < arr.length; i++) {
      console.log(arr[i]);
      const values = [
        arr[i].hofAadharNo,
        arr[i].name,
        arr[i].dob,
        arr[i].sex,
        arr[i].phoneNo,
        arr[i].bloodGroup,
        arr[i].Education,
        arr[i].Occupation,
        arr[i].Category,
      ];
      db.query(q, [values], (err, data) => {
        if (err) return res.json(err.message);
        return res.json("Book has been created successfully");
      });
    }
  }
});

app.delete("/books/:id", (req, res) => {
  const bookId = req.params.id;
  const query = "DELETE FROM TEST.BOOKS WHERE id= ?";
  db.query(query, [bookId], (err, data) => {
    if (err) return res.json(err.message);
    return res.json("Book has been deleted successfully");
  });
});

app.put("/books/:id", (req, res) => {
  const bookId = req.params.id;
  const query =
    "Update test.books set `title`= ? ,`desc`= ? ,`cover` =?  where id = ?";
  const values = [req.body.title, req.body.desc, req.body.cover];
  db.query(query, [...values, bookId], (err, data) => {
    if (err) return res.json(err.message);
    return res.json("Book has been updated successfully");
  });
});

app.post("/shareArticles", (req, res) => {
  const q =
    "Insert into fatakdb.articles(`title`,`content`,`author`) VALUES (?)";

  const values = [req.body.title, req.body.content, req.body.author];
  console.log(req.body);
  //console.log(foreginKey);
  db.query(q, [values], (err, data) => {
    if (err) return res.json(err.message);
    return res.json("Article has been inserted.");
  });
});
app.listen(8800, () => {
  console.log("Connected to backend!");
});
